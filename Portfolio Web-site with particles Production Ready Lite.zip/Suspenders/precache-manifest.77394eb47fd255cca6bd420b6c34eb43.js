self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7ef405d5ba94bafd564b42e788d9b840",
    "url": "./index.html"
  },
  {
    "revision": "d93ffc81183a3be166af",
    "url": "./static/css/main.0d3cd1e6.chunk.css"
  },
  {
    "revision": "6fafce633044364aff6e",
    "url": "./static/js/2.5df5acda.chunk.js"
  },
  {
    "revision": "d93ffc81183a3be166af",
    "url": "./static/js/main.d1563b90.chunk.js"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime~main.d653cc00.js"
  },
  {
    "revision": "d2c38c53609180099006fed37b6a168f",
    "url": "./static/media/MI.d2c38c53.svg"
  },
  {
    "revision": "30f0707118fb960665491424c115ac44",
    "url": "./static/media/shopping-bag.30f07071.svg"
  }
]);